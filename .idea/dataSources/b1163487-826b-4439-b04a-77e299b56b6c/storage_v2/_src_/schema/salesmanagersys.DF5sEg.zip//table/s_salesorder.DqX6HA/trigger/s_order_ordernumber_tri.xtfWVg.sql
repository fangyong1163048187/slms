create trigger s_order_ordernumber_tri
  before INSERT
  on s_salesorder
  for each row
  set new.ordernumber = concat('OD',DATE_FORMAT(now(), '%Y%m%d%H%i%s'),(select lpad(round(round(rand(),4)*1000),4,'0') FROM dual));

