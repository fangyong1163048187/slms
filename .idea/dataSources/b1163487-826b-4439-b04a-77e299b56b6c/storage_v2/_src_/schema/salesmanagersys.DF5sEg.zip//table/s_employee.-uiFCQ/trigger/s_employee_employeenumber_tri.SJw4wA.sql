create trigger s_employee_employeenumber_tri
  before INSERT
  on s_employee
  for each row
  set new.employeenumber = concat('ED',DATE_FORMAT(now(), '%Y%m%d%H%i%s'),(select lpad(round(round(rand(),4)*1000),4,'0') FROM dual));

