create trigger s_product_productnumber_tri
  before INSERT
  on s_product
  for each row
  set new.productnumber = concat('PD',DATE_FORMAT(now(), '%Y%m%d%H%i%s'),(select lpad(round(round(rand(),4)*1000),4,'0') FROM dual));

