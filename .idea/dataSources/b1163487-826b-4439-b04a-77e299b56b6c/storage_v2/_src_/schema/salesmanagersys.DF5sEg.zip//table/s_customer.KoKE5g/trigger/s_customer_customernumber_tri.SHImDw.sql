create trigger s_customer_customernumber_tri
  before INSERT
  on s_customer
  for each row
  set new.customernumber = concat('CD',DATE_FORMAT(now(), '%Y%m%d%H%i%s'),(select lpad(round(round(rand(),4)*1000),4,'0') FROM dual));

