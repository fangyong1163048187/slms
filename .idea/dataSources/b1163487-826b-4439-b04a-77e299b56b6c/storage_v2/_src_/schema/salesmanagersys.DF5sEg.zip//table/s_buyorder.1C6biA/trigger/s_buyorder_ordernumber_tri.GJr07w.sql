create trigger s_buyorder_ordernumber_tri
  before INSERT
  on s_buyorder
  for each row
  set new.ordernumber = concat('OD',date_format(now(),'%Y%m%d%H%i%s'),(select lpad(round(round(rand(),4)*1000),4,'0') FROM dual));

